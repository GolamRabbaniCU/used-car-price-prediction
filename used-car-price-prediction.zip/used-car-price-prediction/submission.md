# Used Car Price Prediction — Submission

**GitHub Repository:** https://github.com/yourusername/used-car-price-prediction
**Live App:** https://your-app-url.streamlit.app

*(Replace both links above with your actual GitHub repo URL and Streamlit Cloud URL before submitting.)*

## Key EDA Findings
- `Present_Price` has by far the strongest correlation with `Selling_Price` (r ≈ 0.88).
- `Selling_Price` is heavily right-skewed (skew ≈ 2.49); most cars sell under 10 Lakhs, with a
  long tail of premium vehicles.
- Diesel and Automatic cars tend to have higher median selling prices than Petrol/Manual cars.
- Cars with a higher `Car_Age` show lower resale value, though the effect interacts with
  `Present_Price` (an old premium car can still outsell a new budget car).
- `Kms_Driven` contained one extreme outlier (500,000 km) that was capped before training.
- 2 exact duplicate rows were found and removed prior to the train/test split.

## Features Used in the Final Model
`Present_Price`, `Kms_Driven`, `Fuel_Type`, `Seller_Type`, `Transmission`, `Owner`, `Car_Age`

## Final Model
- **Model:** XGBoost Regressor (tuned: `n_estimators=300`, `max_depth=4`, `learning_rate=0.05`)
- **Test R²:** 0.8483
- **Test RMSE:** 1.98 Lakhs

## Model Comparison

| Model | Train R² | Test R² | Test RMSE |
|-------------------|----------|---------|-----------|
| XGBoost (tuned) | 0.9986 | 0.8483 | 1.9773 |
| XGBoost (default) | 1.0000 | 0.7921 | 2.3147 |
| Linear Regression | 0.9056 | 0.7769 | 2.3981 |
| Ridge Regression (alpha=0.1) | 0.9056 | 0.7768 | 2.3985 |
| LightGBM (tuned) | 0.9114 | 0.6930 | 2.8129 |
| LightGBM (default) | 0.9027 | 0.6836 | 2.8558 |
| Random Forest (n=100) | 0.9825 | 0.4845 | 3.6452 |

**Why XGBoost:** Highest Test R² among all five models, and while there is a moderate
overfitting gap (Train R² 0.999 vs Test R² 0.848), it still generalized noticeably better than
Linear/Ridge Regression and Random Forest on this split. Given the small dataset size (299 rows
after de-duplication), results are sensitive to the exact train/test split; cross-validation
would be a natural next step to get a more stable estimate.
